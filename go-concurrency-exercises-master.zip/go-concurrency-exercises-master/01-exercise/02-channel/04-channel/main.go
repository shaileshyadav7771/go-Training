package main

// TODO: Implement relaying of message with Channel Direction

func genMsg() {
	// send message on ch1
}

func relayMsg() {
	// recv message on ch1
	// send it on ch2
}

func main() {
	// create ch1 and ch2

	// spine goroutine genMsg and relayMsg

	// recv message on ch2
}
